# قارئ الأوراق للمكفوفين (Android / Java)

## التشغيل
1. افتح المجلد في Android Studio (Hedgehog أو أحدث) وانتظر Gradle Sync.
2. حمّل ملفي اللغة وضعهما في `app/src/main/assets/tessdata/`:
   - ara.traineddata
   - eng.traineddata
   من: https://github.com/tesseract-ocr/tessdata_best  (أو tessdata_fast لسرعة أكبر)
3. شغّل التطبيق على هاتف حقيقي (الكاميرا لا تعمل جيداً على المحاكي).

## آلية العمل
- PaperDetector: يحلل الإطارات، يكتشف الورقة، ويوجّه صوتياً (قرّب / ابعد / حرّك يميناً ...) ثم يلتقط تلقائياً عند الثبات.
- OcrEngine: Tesseract بدون إنترنت (عربي + إنجليزي).
- Speaker: قراءة صوتية فقرة فقرة مع إيقاف وإعادة وتخطٍّ.
- النصوص المقروءة تُحفظ في files/scans داخل التطبيق.
