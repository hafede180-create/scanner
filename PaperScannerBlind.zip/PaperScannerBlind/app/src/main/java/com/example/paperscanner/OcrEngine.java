package com.example.paperscanner;

import android.content.Context;
import android.graphics.Bitmap;

import com.googlecode.tesseract.android.TessBaseAPI;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/** التعرف على النص بدون إنترنت باستخدام Tesseract. ملفات اللغة في assets/tessdata */
public class OcrEngine {

    private final Context ctx;
    private TessBaseAPI api;

    public OcrEngine(Context ctx) {
        this.ctx = ctx.getApplicationContext();
    }

    /** @param lang مثل "ara+eng" */
    public synchronized void init(String lang) throws IOException {
        File tessDir = new File(ctx.getFilesDir(), "tessdata");
        if (!tessDir.exists() && !tessDir.mkdirs()) throw new IOException("cannot create tessdata dir");

        for (String l : lang.split("\\+")) {
            File f = new File(tessDir, l + ".traineddata");
            if (!f.exists()) copyAsset("tessdata/" + l + ".traineddata", f);
        }
        api = new TessBaseAPI();
        if (!api.init(ctx.getFilesDir().getAbsolutePath(), lang)) {
            api = null;
            throw new IOException("Tesseract init failed");
        }
    }

    public synchronized String recognize(Bitmap bmp) {
        if (api == null) return "";
        api.setImage(bmp);
        String text = api.getUTF8Text();
        api.clear();
        return text == null ? "" : text.trim();
    }

    public synchronized void release() {
        if (api != null) {
            api.recycle();
            api = null;
        }
    }

    private void copyAsset(String assetPath, File dest) throws IOException {
        try (InputStream in = ctx.getAssets().open(assetPath);
             OutputStream out = new FileOutputStream(dest)) {
            byte[] buf = new byte[16 * 1024];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        } catch (IOException e) {
            if (dest.exists()) //noinspection ResultOfMethodCallIgnored
                dest.delete();
            throw e;
        }
    }
}
