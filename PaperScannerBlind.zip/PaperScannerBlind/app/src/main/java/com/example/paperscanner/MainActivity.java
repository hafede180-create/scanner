package com.example.paperscanner;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageCapture;
import androidx.camera.core.ImageCaptureException;
import androidx.camera.core.ImageProxy;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.content.ContextCompat;

import com.google.common.util.concurrent.ListenableFuture;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity implements PaperDetector.Listener {

    private enum State { IDLE, GUIDING, CAPTURING, PROCESSING, READING }

    private PreviewView previewView;
    private TextView statusText;
    private Speaker speaker;
    private OcrEngine ocr;
    private PaperDetector detector;
    private ImageCapture imageCapture;

    private final ExecutorService cameraExecutor = Executors.newSingleThreadExecutor();
    private final ExecutorService ocrExecutor = Executors.newSingleThreadExecutor();

    private volatile State state = State.IDLE;
    private volatile boolean ocrReady = false;

    private final ActivityResultLauncher<String> permissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
                if (granted) startCamera();
                else {
                    setStatus("لم يتم منح إذن الكاميرا");
                    speaker.speak("لم يتم منح إذن الكاميرا. لا يمكن للتطبيق العمل بدونه");
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        previewView = findViewById(R.id.previewView);
        statusText = findViewById(R.id.statusText);

        speaker = new Speaker(this);
        speaker.setFinishListener(() -> {
            state = State.IDLE;
            setStatus("انتهت القراءة");
            speaker.speak("انتهت القراءة. اضغط مسح ورقة جديدة للمتابعة");
        });
        ocr = new OcrEngine(this);
        detector = new PaperDetector(this);

        ((Button) findViewById(R.id.btnScan)).setOnClickListener(v -> startGuiding());
        ((Button) findViewById(R.id.btnPause)).setOnClickListener(v -> {
            if (!speaker.hasText()) return;
            boolean paused = speaker.togglePause();
            if (!paused) state = State.READING;
            setStatus(paused ? "القراءة متوقفة" : "جاري القراءة");
        });
        ((Button) findViewById(R.id.btnRepeat)).setOnClickListener(v -> {
            if (!speaker.hasText()) return;
            state = State.READING;
            setStatus("جاري القراءة");
            speaker.restart();
        });
        ((Button) findViewById(R.id.btnNext)).setOnClickListener(v -> {
            if (!speaker.hasText()) return;
            state = State.READING;
            speaker.next();
        });

        initOcrAsync();

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED) {
            startCamera();
        } else {
            speaker.speak("مرحباً. سيطلب التطبيق إذن الكاميرا. وافق عليه للمتابعة");
            permissionLauncher.launch(Manifest.permission.CAMERA);
        }
    }

    private void initOcrAsync() {
        ocrExecutor.execute(() -> {
            try {
                ocr.init("ara+eng");
                ocrReady = true;
            } catch (Exception e) {
                runOnUiThread(() -> {
                    setStatus("ملفات اللغة غير موجودة");
                    speaker.speak("تعذر تحميل محرك القراءة. ملفات اللغة غير موجودة داخل التطبيق");
                });
            }
        });
    }

    private void startCamera() {
        ListenableFuture<ProcessCameraProvider> future = ProcessCameraProvider.getInstance(this);
        future.addListener(() -> {
            try {
                ProcessCameraProvider provider = future.get();

                Preview preview = new Preview.Builder().build();
                preview.setSurfaceProvider(previewView.getSurfaceProvider());

                ImageAnalysis analysis = new ImageAnalysis.Builder()
                        .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                        .build();
                analysis.setAnalyzer(cameraExecutor, detector);

                imageCapture = new ImageCapture.Builder()
                        .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                        .build();

                provider.unbindAll();
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA,
                        preview, analysis, imageCapture);

                startGuiding();
            } catch (Exception e) {
                setStatus("تعذر تشغيل الكاميرا");
                speaker.speak("تعذر تشغيل الكاميرا");
            }
        }, ContextCompat.getMainExecutor(this));
    }

    private void startGuiding() {
        state = State.GUIDING;
        detector.reset();
        speaker.stopAll();
        setStatus(getString(R.string.status_start));
        speaker.speak("وجّه الكاميرا نحو الورقة");
    }

    // ---- PaperDetector.Listener (يُستدعى من خيط التحليل) ----

    @Override
    public void onGuidance(String message) {
        runOnUiThread(() -> {
            if (state != State.GUIDING) return;
            setStatus(message);
            speaker.speakGuidance(message);
        });
    }

    @Override
    public void onReadyToCapture() {
        runOnUiThread(this::capture);
    }

    private void capture() {
        if (state != State.GUIDING || imageCapture == null) return;
        state = State.CAPTURING;
        vibrate();
        setStatus("جاري الالتقاط");
        speaker.speak("تم. لا تحرك الهاتف");

        imageCapture.takePicture(ContextCompat.getMainExecutor(this),
                new ImageCapture.OnImageCapturedCallback() {
                    @Override
                    public void onCaptureSuccess(@NonNull ImageProxy image) {
                        state = State.PROCESSING;
                        setStatus("جاري قراءة النص");
                        ocrExecutor.execute(() -> handleImage(image));
                    }

                    @Override
                    public void onError(@NonNull ImageCaptureException e) {
                        speaker.speak("فشل الالتقاط. سأحاول مرة أخرى");
                        startGuiding();
                    }
                });
    }

    private void handleImage(ImageProxy image) {
        Bitmap bmp;
        try {
            java.nio.ByteBuffer buffer = image.getPlanes()[0].getBuffer();
            byte[] bytes = new byte[buffer.remaining()];
            buffer.get(bytes);
            Bitmap raw = android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
            Matrix m = new Matrix();
            m.postRotate(image.getImageInfo().getRotationDegrees());
            bmp = Bitmap.createBitmap(raw, 0, 0, raw.getWidth(), raw.getHeight(), m, true);
            int maxSide = Math.max(bmp.getWidth(), bmp.getHeight());
            if (maxSide > 2600) {
                float s = 2600f / maxSide;
                bmp = Bitmap.createScaledBitmap(bmp, Math.round(bmp.getWidth() * s),
                        Math.round(bmp.getHeight() * s), true);
            }
        } finally {
            image.close();
        }

        if (!ocrReady) {
            runOnUiThread(() -> {
                speaker.speak("محرك القراءة غير جاهز");
                state = State.IDLE;
            });
            return;
        }

        final String text = ocr.recognize(bmp);
        if (text.isEmpty()) {
            runOnUiThread(() -> {
                speaker.speak("لم أجد نصاً في الصورة. سأحاول مرة أخرى");
                startGuiding();
            });
            return;
        }
        saveText(text);
        runOnUiThread(() -> {
            state = State.READING;
            setStatus("جاري القراءة");
            speaker.startReading(text);
        });
    }

    private void saveText(String text) {
        try {
            File dir = new File(getFilesDir(), "scans");
            //noinspection ResultOfMethodCallIgnored
            dir.mkdirs();
            String name = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".txt";
            try (OutputStreamWriter w = new OutputStreamWriter(
                    new FileOutputStream(new File(dir, name)), "UTF-8")) {
                w.write(text);
            }
        } catch (Exception ignored) {
        }
    }

    private void vibrate() {
        Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        if (v == null) return;
        if (Build.VERSION.SDK_INT >= 26) {
            v.vibrate(VibrationEffect.createOneShot(250, VibrationEffect.DEFAULT_AMPLITUDE));
        } else {
            v.vibrate(250);
        }
    }

    private void setStatus(String s) {
        runOnUiThread(() -> statusText.setText(s));
    }

    @Override
    protected void onStop() {
        super.onStop();
        speaker.stopAll();
        if (state == State.READING) state = State.IDLE;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        speaker.shutdown();
        cameraExecutor.shutdown();
        ocrExecutor.execute(() -> ocr.release());
        ocrExecutor.shutdown();
    }
}
