package com.example.paperscanner;

import androidx.annotation.NonNull;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageProxy;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

/**
 * يحلل إطارات الكاميرا لاكتشاف الورقة (أكثر منطقة ساطعة) ويعطي توجيهاً صوتياً.
 * عندما تكتمل الورقة داخل الإطار وتثبت لمدة قصيرة يطلب الالتقاط تلقائياً.
 */
public class PaperDetector implements ImageAnalysis.Analyzer {

    public interface Listener {
        void onGuidance(String message);
        void onReadyToCapture();
    }

    private static final int N = 56;              // حجم شبكة العينات
    private static final float EDGE = 0.03f;      // الحافة التي تعني أن الورقة مقطوعة
    private static final long STABLE_MS = 1200;   // مدة الثبات قبل الالتقاط

    private final Listener listener;
    private volatile boolean enabled = true;
    private float[] prevBox;
    private long stableSince = 0;

    public PaperDetector(Listener listener) {
        this.listener = listener;
    }

    public void reset() {
        prevBox = null;
        stableSince = 0;
        enabled = true;
    }

    @Override
    public void analyze(@NonNull ImageProxy image) {
        try {
            if (enabled) process(image);
        } finally {
            image.close();
        }
    }

    private void process(ImageProxy image) {
        ImageProxy.PlaneProxy plane = image.getPlanes()[0];
        ByteBuffer buf = plane.getBuffer();
        int rowStride = plane.getRowStride();
        int pxStride = plane.getPixelStride();
        int w = image.getWidth(), h = image.getHeight();

        int[] grid = new int[N * N];
        int min = 255, max = 0;
        long sum = 0;
        for (int gy = 0; gy < N; gy++) {
            int y = (int) ((gy + 0.5f) * h / N);
            for (int gx = 0; gx < N; gx++) {
                int x = (int) ((gx + 0.5f) * w / N);
                int v = buf.get(y * rowStride + x * pxStride) & 0xFF;
                grid[gy * N + gx] = v;
                if (v < min) min = v;
                if (v > max) max = v;
                sum += v;
            }
        }
        float mean = sum / (float) grid.length;

        // مشهد متجانس: إما ورقة تملأ الإطار أو لا شيء
        if (max - min < 40) {
            if (mean > 110) say("ابعد الهاتف عن الورقة قليلاً");
            else say("لا أرى ورقة. حرّك الهاتف فوق الورقة");
            unstable();
            return;
        }

        int th = otsu(grid);
        int[] col = new int[N], row = new int[N];
        int bright = 0;
        for (int y = 0; y < N; y++) {
            for (int x = 0; x < N; x++) {
                if (grid[y * N + x] > th) {
                    col[x]++;
                    row[y]++;
                    bright++;
                }
            }
        }

        int minX = -1, maxX = -1, minY = -1, maxY = -1;
        for (int i = 0; i < N; i++) {
            if (col[i] >= 3) { if (minX < 0) minX = i; maxX = i; }
            if (row[i] >= 3) { if (minY < 0) minY = i; maxY = i; }
        }
        if (minX < 0 || minY < 0 || th < 60) {
            say("لا أرى ورقة. حرّك الهاتف فوق الورقة");
            unstable();
            return;
        }
        float fill = bright / (float) ((maxX - minX + 1) * (maxY - minY + 1));
        if (fill < 0.5f) {
            say("لا أرى ورقة واضحة. تأكد من الإضاءة");
            unstable();
            return;
        }

        float[] box = rotateBox(
                minX / (float) N, minY / (float) N,
                (maxX + 1) / (float) N, (maxY + 1) / (float) N,
                image.getImageInfo().getRotationDegrees());
        float coverage = (box[2] - box[0]) * (box[3] - box[1]);

        boolean L = box[0] < EDGE, T = box[1] < EDGE;
        boolean R = box[2] > 1 - EDGE, B = box[3] > 1 - EDGE;
        int touched = (L ? 1 : 0) + (T ? 1 : 0) + (R ? 1 : 0) + (B ? 1 : 0);

        if (coverage > 0.92f || touched >= 3) {
            say("ابعد الهاتف عن الورقة قليلاً");
            unstable();
        } else if (touched > 0) {
            List<String> dirs = new ArrayList<>();
            if (L) dirs.add("اليسار");
            if (R) dirs.add("اليمين");
            if (T) dirs.add("الأعلى");
            if (B) dirs.add("الأسفل");
            say("حرّك الهاتف نحو " + join(dirs));
            unstable();
        } else if (coverage < 0.35f) {
            say("قرّب الهاتف من الورقة");
            unstable();
        } else {
            checkStable(box);
        }
    }

    private void checkStable(float[] box) {
        long now = System.currentTimeMillis();
        boolean same = prevBox != null;
        if (same) {
            for (int i = 0; i < 4; i++) {
                if (Math.abs(prevBox[i] - box[i]) > 0.04f) { same = false; break; }
            }
        }
        prevBox = box;
        if (!same) {
            stableSince = 0;
            say("الورقة ظاهرة. ثبّت الهاتف");
            return;
        }
        if (stableSince == 0) stableSince = now;
        if (now - stableSince >= STABLE_MS) {
            enabled = false;
            listener.onReadyToCapture();
        }
    }

    private void unstable() {
        prevBox = null;
        stableSince = 0;
    }

    private void say(String msg) {
        listener.onGuidance(msg);
    }

    private static String join(List<String> l) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < l.size(); i++) {
            if (i > 0) sb.append(" و");
            sb.append(l.get(i));
        }
        return sb.toString();
    }

    /** تحويل الصندوق من اتجاه الحساس إلى اتجاه الشاشة */
    private static float[] rotateBox(float l, float t, float r, float b, int deg) {
        float[] p1 = rot(l, t, deg), p2 = rot(r, b, deg);
        return new float[]{
                Math.min(p1[0], p2[0]), Math.min(p1[1], p2[1]),
                Math.max(p1[0], p2[0]), Math.max(p1[1], p2[1])};
    }

    private static float[] rot(float x, float y, int deg) {
        switch (deg) {
            case 90:  return new float[]{1 - y, x};
            case 180: return new float[]{1 - x, 1 - y};
            case 270: return new float[]{y, 1 - x};
            default:  return new float[]{x, y};
        }
    }

    private static int otsu(int[] g) {
        int[] hist = new int[256];
        for (int v : g) hist[v]++;
        int total = g.length;
        float sum = 0;
        for (int i = 0; i < 256; i++) sum += i * hist[i];
        float sumB = 0, best = 0;
        int wB = 0, th = 128;
        for (int t = 0; t < 256; t++) {
            wB += hist[t];
            if (wB == 0) continue;
            int wF = total - wB;
            if (wF == 0) break;
            sumB += t * hist[t];
            float mB = sumB / wB, mF = (sum - sumB) / wF;
            float between = (float) wB * wF * (mB - mF) * (mB - mF);
            if (between > best) { best = between; th = t; }
        }
        return th;
    }
}
