package com.example.paperscanner;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** غلاف للنطق الصوتي: رسائل التوجيه + قراءة النص فقرة فقرة مع إيقاف وتخطٍّ. كل الدوال تُستدعى من الخيط الرئيسي. */
public class Speaker {

    public interface FinishListener { void onFinished(); }

    private final Handler main = new Handler(Looper.getMainLooper());
    private TextToSpeech tts;
    private boolean ready;
    private final List<Runnable> pending = new ArrayList<>();
    private final List<String> chunks = new ArrayList<>();
    private int index, token;
    private boolean reading, paused;
    private long lastGuideTime;
    private String lastGuide = "";
    private FinishListener finishListener;

    public Speaker(Context ctx) {
        tts = new TextToSpeech(ctx.getApplicationContext(), status -> {
            if (status != TextToSpeech.SUCCESS) return;
            int r = tts.setLanguage(new Locale("ar"));
            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts.setLanguage(Locale.getDefault());
            }
            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override public void onStart(String id) { }
                @Override public void onError(String id) { }
                @Override public void onDone(String id) {
                    if (id == null || id.startsWith("m")) return;
                    final int t = Integer.parseInt(id);
                    main.post(() -> {
                        if (reading && !paused && t == token) {
                            index++;
                            speakCurrent();
                        }
                    });
                }
            });
            main.post(() -> {
                ready = true;
                for (Runnable p : pending) p.run();
                pending.clear();
            });
        });
    }

    public void setFinishListener(FinishListener l) { finishListener = l; }

    private void run(Runnable r) {
        if (ready) r.run(); else pending.add(r);
    }

    /** نطق رسالة قصيرة وإلغاء ما قبلها (يوقف القراءة الجارية) */
    public void speak(String text) {
        reading = false;
        paused = false;
        token++;
        run(() -> tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "m" + System.nanoTime()));
    }

    /** رسائل التوجيه: لا تتكرر بسرعة */
    public void speakGuidance(String msg) {
        long now = System.currentTimeMillis();
        boolean changed = !msg.equals(lastGuide);
        if ((changed && now - lastGuideTime > 2200) || now - lastGuideTime > 5000) {
            lastGuide = msg;
            lastGuideTime = now;
            speak(msg);
        }
    }

    public void startReading(String text) {
        chunks.clear();
        chunks.addAll(split(text));
        index = 0;
        reading = true;
        paused = false;
        run(this::speakCurrent);
    }

    private void speakCurrent() {
        if (index >= chunks.size()) {
            reading = false;
            if (finishListener != null) finishListener.onFinished();
            return;
        }
        int t = ++token;
        tts.speak(chunks.get(index), TextToSpeech.QUEUE_FLUSH, null, String.valueOf(t));
    }

    /** @return true إذا أصبحت القراءة متوقفة */
    public boolean togglePause() {
        if (chunks.isEmpty()) return false;
        if (!paused && reading) {
            paused = true;
            token++;
            tts.stop();
            return true;
        }
        paused = false;
        reading = true;
        speakCurrent();
        return false;
    }

    public void restart() {
        if (chunks.isEmpty()) return;
        index = 0;
        paused = false;
        reading = true;
        speakCurrent();
    }

    public void next() {
        if (chunks.isEmpty()) return;
        index++;
        paused = false;
        reading = true;
        speakCurrent();
    }

    public boolean hasText() { return !chunks.isEmpty(); }

    public void stopAll() {
        reading = false;
        paused = false;
        token++;
        if (tts != null) tts.stop();
    }

    public void shutdown() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
            tts = null;
        }
    }

    static List<String> split(String text) {
        List<String> out = new ArrayList<>();
        for (String para : text.split("\\n+")) {
            para = para.trim();
            if (para.isEmpty()) continue;
            for (String s : para.split("(?<=[.!?؟۔])\\s+")) {
                s = s.trim();
                while (s.length() > 300) {
                    int cut = s.lastIndexOf(' ', 300);
                    if (cut <= 0) cut = 300;
                    out.add(s.substring(0, cut).trim());
                    s = s.substring(cut).trim();
                }
                if (!s.isEmpty()) out.add(s);
            }
        }
        return out;
    }
}
